// stdafx.cpp : source file that includes just the standard includes
// gifanim.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// Reference any additional headers you need in STDAFX.H
// and not in this file
